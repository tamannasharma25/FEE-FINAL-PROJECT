import React from 'react'
import './App.css'
import First from './components/Firstpage'
import Second from './components/Secondpage'
import Third from './components/Thirdpage'
import Fourth from './components/Fourthpage'
import Fifth from './components/Fifthpage'
import Sixth from './components/Sixthpage'
import Seventh from './components/Seventhpage'
import Eight from './components/Eightpage'
import Nineth from './components/Ninthpage'

function App() {
 

  return (
    <>
      <First/>
      <Second/>
      <Third/>
      <Fourth/>
      <Fifth/>
      <Sixth/>
      <Seventh/>
      <Eight/>
      <Nineth/>
    </>
  )
}

export default App
