import React from "react";

const Sixth = ()=>{
    return(
        <>
         <section className="part6" >
          <div className="innerpart6" id="BB" />
        </section>
        </>
    )
}
export default Sixth