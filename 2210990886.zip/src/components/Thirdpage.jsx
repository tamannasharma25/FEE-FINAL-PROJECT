import React from "react";

const Third = ()=>{
    return(
        <>
        <section className="part3" id="m">
          <div className="innerpart3">
            <div className="forbgagain">
              <div className="contentforpart3">
                <div className="headingAgainStyled">
                  <div className="tata">
                    <img src="./images/tatatwhite.png" alt="" />
                  </div>
                  <p className="about2">Our Food Quality</p>
                  <div className="tata">
                    <img src="./images/tatatwhite.png" alt="" />
                  </div>
                </div>
                <div className="contentdiv3">
                  <p>
                    Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do
                    <br />
                    eiusmod tempor incididunt ut labore et dolore magna aliqua. Quis
                    <br />
                    ipsum suspendisse ultrices gravida.
                  </p>
                </div>
                <div className="visi">
                  <p className="goldupper2">
                    <span className="ooo1">Double The Fun</span> <br />
                    On Every Saturday
                    <br />
                    <span className="Gold21">Get upto 50% discount</span>
                  </p>
                </div>
              </div>
            </div>
          </div>
        </section>
        </>
    )
}
export default Third