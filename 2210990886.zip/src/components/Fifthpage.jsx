import React from "react";

const Fifth = ()=>{
    return(
        <>
        
        <section className="part5" id="b">
          <div className="innerpart5">
            <div className="BookNow">
              <div className="headingpart5">
                <div className="tata">
                  <img src="./images/Tatat.png" alt="" />
                </div>
                <p className="about">Book Now</p>
                <div className="tata">
                  <img src="./images/Tatat.png" alt="" />
                </div>
              </div>
            </div>
            <div className="Tagline">
              <p>Book Your Table Now And Have A Great Meal !</p>
            </div>
            <form className="Form">
              <label htmlFor="fulln" className="formele" id="fullname">
                Your Full Name?
                <input
                  placeholder="Full Name"
                  type="text"
                  name="fullname"
                  id="fulln"
                />
              </label>
              <label htmlFor="Emaili" className="formele" id="Email">
                Your Email?
                <input placeholder="Email" type="text" name="Email" id="Emaili" />
              </label>
              <label htmlFor="peoplef" className="formele" id="people">
                How many People?
                <select name="People" id="peoplef">
                  <option value={1}>1</option>
                  <option value={1}>2</option>
                  <option value={1}>3</option>
                  <option value={1}>4</option>
                  <option value={1}>5</option>
                </select>
              </label>
              <label htmlFor="TIme" className="formele" id="time">
                What Time?
                <input placeholder="Time" type="time" name="fullname" id="TIme" />
              </label>
              <label htmlFor="date1" className="formele" id="date">
                Date?
                <input type="date" name="date" id="date1" />
              </label>
              <label htmlFor="PhNum" className="formele" id="phoneNum">
                Your Phone Number
                <input
                  placeholder="Phone Number"
                  type="text"
                  name="Phone Number"
                  id="PhNum"
                />
              </label>
            </form>
            <div className="Submit">
              <button className="SubmitButton">Submit</button>
            </div>
          </div>
        </section>
        </>
    )
}
export default Fifth