import React from "react";

const Seventh = ()=>{
    return(
        <>
         <section className="part7" id="c">
          <div className="innerpart7">
            <div className="part7Con">
              <p className="contt">
                Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do
                eiusmod tempor incidi- <br /> dunt ut labore et dolore magna aliqua.
                Ut enim ad minim veniam, quis{" "}
              </p>
              <p className="Writer">Linda Steward</p>
            </div>
          </div>
        </section>
        </>
    )
}
export default Seventh