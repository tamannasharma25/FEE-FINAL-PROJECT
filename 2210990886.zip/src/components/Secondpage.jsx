import React from "react";

const Second = ()=>{
    return(
        <>
         <section className="part2" id="ab">
          <div className="innerpart2">
            <div className="contentpart2">
              <div className="HeadingStyled">
                <div className="tata">
                  <img src="./images/Tatat.png" alt="" />
                </div>
                <p className="about">
                  ABOUT <span className="spec">L'Gran</span>
                </p>
                <div className="tata">
                  <img src="./images/Tatat.png" alt="" />
                </div>
              </div>
              <div className="content">
                <p>
                  Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do
                  eiusmod tempor incididunt ut labore et dolore magna aliqua. Quis
                  ipsum suspendisse ultrices gravida. Risus commodo vive rra maecenas
                  accumsan lacus vel facilisis. Lorem ipsum dolor sit amet,
                  consectetur adipisicing elit, sed do eiusmod tempor incid idunt ut
                  labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud
                  exercitation ullamco laboris nisi ut aliquip ex ea commodo
                  consequat. Duis aute irure d
                </p>
              </div>
              <div className="visi">
                <p className="goldupper">
                  Visit or Book <span className="Gold2">Now</span>
                </p>
              </div>
            </div>
          </div>
        </section>
        </>
    )
}
export default Second