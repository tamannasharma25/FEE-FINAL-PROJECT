import React from "react";

const Fourth = ()=>{
    return(
        <>
         <section className="part4" id="g">
          <div className="innerpart4">
            <div className="headingpart4">
              <div className="tata">
                <img src="./images/Tatat.png" alt="" />
              </div>
              <p className="about">Gallery</p>
              <div className="tata">
                <img src="./images/Tatat.png" alt="" />
              </div>
            </div>
            <div className="images" />
          </div>
        </section>
        </>
    )
}
export default Fourth