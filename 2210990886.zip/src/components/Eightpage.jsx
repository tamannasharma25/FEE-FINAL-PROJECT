import React from "react";

const Eight = ()=>{
    return(
        <>
         <section className="part8">
          <div className="innerpart8">
            <div className="mealcont">
              <h1>Enjoy Our Best Meal</h1>
              <p>
                Lorem ipsum dolor sit amet, cosectetur adi <br />
                piscing elit, sed do eiusmod tempor incididunt <br /> ut labore
                etdolore magna sed do eiusmod <br /> tempor incididunt ut labore
                etdolore
              </p>
              <p className="COntect">Contact Us Now</p>
            </div>
          </div>
        </section>
        </>
    )
}
export default Eight