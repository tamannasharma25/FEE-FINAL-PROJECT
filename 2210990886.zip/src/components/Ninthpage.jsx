import React from "react";

const Nineth = ()=>{
    return(
        <>
         <footer className="footer">
          <div className="innerFooterContent">
            <div className="ContentFinalFooter">
              <img src="./images/logo.png" alt="" />
              <ul className="footlinks">
                <li>About Us</li>
                <li>Menu</li>
                <li>Bookings</li>
                <li>Gallery</li>
                <li>Contact</li>
                <li>Blog</li>
              </ul>
              <ul className="contacts">
                <li>
                  <img src="./images/fb.png" alt="" />
                </li>
                <li>
                  <img src="./images/twitter.png" alt="" />
                </li>
                <li>
                  <img src="./images/insta.png" alt="" />
                </li>
                <li>
                  <img src="./images/pinterest.png" alt="" />
                </li>
              </ul>
            </div>
          </div>
        </footer>
        </>
    )
}
export default Nineth