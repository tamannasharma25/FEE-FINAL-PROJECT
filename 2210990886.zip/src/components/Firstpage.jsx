import React from "react";
 const First=() =>{
    return(
        <>
        <section className="hero">
          <div className="innerHero">
            <div className="ForBg">
              <ul className="Nav">
                <li className="ListIn">
                  <ul className="innerList">
                    <li className="textList"> <a href="#ab">About Us</a></li>
                    <li className="textList"><a href="#m">Menu</a></li>
                    <li className="textList"><a href="#g">Gallery</a></li>
                  </ul>
                </li>
                <li>
                  <img src="./images/logo.png" alt="" />
                </li>
                <li className="ListIn">
                  <ul className="innerList">
                    <li className="textList"><a href="#b">bookings</a></li>
                    <li className="textList"><a href="#c">Contact</a></li>
                    <li className="textList"><a href="#BB">Blog</a></li>
                  </ul>
                </li>
                <li className="hidden hamLi">
                  <div className="ham" id="ham">
                    <i className="fas fa-bars hamburger" />
                  </div>
                </li>
              </ul>
              <div className="heroContent">
                <div className="TextHero">
                  <p className="con">
                    Start Your Meal With <br />
                    Our Exclusive Menu
                  </p>
                  <p className="Gold">Learn More....</p>
                </div>
                <div className="logo bluronsmall">
                  <img src="./images/logo.png" className="logoimgHero" />
                </div>
                <div className="Booking">
                  <p>
                    Book Your <br />
                    Table <span className="now">Now</span>
                  </p>
                </div>
              </div>
            </div>
          </div>
        </section>

      </>      
    )
 }
 export default First